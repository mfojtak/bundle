from transformers import AutoTokenizer, AutoModelForSequenceClassification, TFAutoModelForSequenceClassification, AutoModelForTokenClassification
from transformers import pipeline
import json

def get_ner():
    tokenizer = AutoTokenizer.from_pretrained("dbmdz/electra-large-discriminator-finetuned-conll03-english", cache_dir="/data/nlp_booth/cache")
    model = AutoModelForTokenClassification.from_pretrained("dbmdz/electra-large-discriminator-finetuned-conll03-english", cache_dir="/data/nlp_booth/cache")
    ner = pipeline('ner', model=model, tokenizer=tokenizer)
    return tokenizer, ner

tokenizer, ner = get_ner()
text = "My name is Sarah and I live in London"
tokens = tokenizer.tokenize(text)
print(tokens)
res = ner(text)
entities = {}
for word in res:
    entities[word["index"]] = word["entity"]

annotated = []
for i, token in enumerate(tokens):
    if i+1 in entities:
        anno = (token, entities[i+1], "#8ef")
        annotated.append(anno)
    else:
        annotated.append(token)

print(annotated)
