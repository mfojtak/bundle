#!/bin/bash
kubectl delete -k ./
kubectl delete -f deployment.yaml